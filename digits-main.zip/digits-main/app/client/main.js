// Start the app.
import '../imports/startup/client/Startup';
// Import the Bootstrap css.
import 'bootstrap/dist/css/bootstrap.min.css';
// Override the default bootstrap styles.
import './style.css';
